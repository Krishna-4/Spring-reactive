import React, { Component } from 'react';
import axios from 'axios';
import './Events.css';
import {ProgressSpinner} from 'primereact/progressspinner';
import {Growl} from 'primereact/growl';

class Reports extends Component {
    constructor(props) {
        super(props);
        this.state = {
            eventsList: [],
            loading: false
        };
        this.sendEmail = this.sendEmail.bind(this);
    }

    componentDidMount() {
        this.setState({ loading: true }, () => {
            axios.get("http://localhost:8080/getEvents").then((res) => {
                this.setState({
                    eventsList: res.data,
                    loading: false
                });
                this.growl.show({life: 3000, severity: 'success', summary: 'Get All Events', detail: 'Events obtained successfully'});
            }).catch(() => {
                this.setState({loading: false});
                this.growl.show({closable:true, sticky: true, severity: 'error', summary: 'Get All Events', detail: 'Get all events failed'});
            });
        });
    }

    sendEmail() {
        const emailVal = document.getElementById("email").value;
        const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (emailVal.match(mailformat)) {
            this.setState({ loading: true }, () => {
                axios.get("http://localhost:8080/sendEmail?email=" + emailVal).then((res) => {
                    this.setState({loading: false});
                    this.growl.show({closable:true, sticky: true, severity: 'success', summary: 'Mail status', detail: 'Mail sent successfully'});
                }).catch((error) => {
                    this.setState({loading: false});
                    this.growl.show({closable:true, sticky: true, severity: 'error', summary: 'Mail status', detail: 'Mailing data failed'});
                });
            });
        } else {
            this.growl.show({closable:true, sticky: true, severity: 'error', summary: 'Invalid Mail', detail: 'Data cannot be sent'});
        }
    }

    render() {
        const { eventsList = [] } = this.state;
        return (
            <>
            {this.state.loading ? 
            <div className="spinner">
                <ProgressSpinner style={{width: '70px', height: '70px'}} strokeWidth="5" fill="#EEEEEE" animationDuration="1s"/>
            </div>
             : <React.Fragment>
                 <Growl ref={(el) => this.growl = el} style={{'marginTop':'5%'}}/>
                <nav className="navbar navbar-expand-md navbar-dark fixed-top nav-bar-custom">
                    <a className="navbar-brand"><i className="fa fa-cubes nav-logo" aria-hidden="true"></i><b>Outreach </b><span className="label-FMS">FMS</span></a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarCollapse">
                        <ul className="navbar-nav mr-auto navbar-custom">
                            <li className="nav-item active">
                                <div> <i className="fa fa-th-large icon-nav" aria-hidden="true"></i> <a className="nav-link nav-link-custom" href="#">Dashboard</a></div>
                            </li>
                            <li className="nav-item active">
                                <div> <i className="fa fa-rocket icon-nav" aria-hidden="true"></i> <a className="nav-link nav-link-custom" href="#">Events</a></div>
                            </li>
                            <li className="nav-item active">
                                <div> <i className="fa fa-tachometer icon-nav" aria-hidden="true"></i> <a className="nav-link nav-link-custom" href="#">Reports</a></div>
                            </li>
                        </ul>
                        <form className="form-inline mt-4 mt-md-2">
                            <i className="fa fa-user-circle-o icon-nav-user" aria-hidden="true"></i> <span className="label-user">Murthy K</span>
                        </form>
                    </div>
                </nav>
                <main role="main" className="mainContent">
                    <div className="clear-10"></div>
                    <div className="card">
                        <div className="card-header card-header-custom-1">
                            <span className="card-title-1">ACTIONS </span>
                            <div className="div-card-icons">
                                <i className="fa fa-dot-circle-o card-icons icon-dots" aria-hidden="true"></i>
                                <i className="fa fa-refresh card-icons icon-refresh" aria-hidden="true"></i>
                                <i className="fa fa-minus-circle card-icons icon-minus" aria-hidden="true"></i>
                                <i className="fa fa-times-circle-o card-icons icon-times" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div className="card-body card-body-custom ">
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="section-1">
                                        <div className="card">
                                            <div className="row no-gutters">
                                                <div className="section-header">
                                                    <i className="fa fa-file-excel-o icon icon-section" aria-hidden="true"></i>
                                                </div>
                                                <div className="col section-body">
                                                    <div className="card-block px-2">
                                                        <b className="card-title" style={{ 'fontSize': '1.3rem' }}>Email Report</b>
                                                    </div>
                                                    <div className="row">
                                                        <div className="col-md-3"><span className="card-text-1">Employee ID</span></div>
                                                        <div className="col-md-4"><input id="email" type="text" name="EmailID" className="form-control" placeholder="Enter Email" /></div>
                                                        <div className="col-md-3"><input type="button" name="btnSendMail" className="btn btn-primary btn-color" value="Send Email" onClick={this.sendEmail} /></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="section-2">
                                        <div className="card">
                                            <div className="row no-gutters">
                                                <div className="col section-body-2">
                                                    <div className="card-block px-2">
                                                        <b className="card-title" style={{ 'fontSize': '1.3rem', 'float': 'right' }}>Future Implementations</b>
                                                        <p className="card-text" style={{ 'float': 'right' }}>This placeholder is used for adding any other actions in future</p>
                                                    </div>
                                                </div>
                                                <div className="section-header-2">
                                                    <div>
                                                        <i className="fa fa-lightbulb-o icon-section-2" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="clear-10"></div>
                    <div className="card">
                        <div className="card-header card-header-custom-1">
                            <span className="card-title-1">EVENTS REPORT</span>
                            <div className="div-card-icons">
                                <i className="fa fa-dot-circle-o card-icons icon-dots" aria-hidden="true"></i>
                                <i className="fa fa-refresh card-icons icon-refresh" aria-hidden="true"></i>
                                <i className="fa fa-minus-circle card-icons icon-minus" aria-hidden="true"></i>
                                <i className="fa fa-times-circle-o card-icons icon-times" aria-hidden="true"></i>
                            </div>
                        </div>
                        <div className="card-body card-body-custom">
                            <div className="button-group" style={{ 'float': 'right' }}>
                                {/* <button className="btn btn-danger"><i className="fa fa-times"></i> CLEAR FILTERS</button> */}
                                <button className="btn btn-primary btn-color"><i className="fa fa-file-excel-o"></i> DOWNLOAD EXCEL</button>
                            </div>
                            <br />
                            <br />
                            <br />
                            <div className="table-responsive">

                                <table className="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col">Event ID</th>
                                            <th scope="col">Base Location</th>
                                            <th scope="col">Beneficiary Name</th>
                                            <th scope="col">Council Name</th>

                                            <th scope="col">Event Name</th>
                                            <th scope="col">Event Description</th>
                                            <th scope="col">Event Date</th>
                                            <th scope="col">Employee ID</th>

                                            <th scope="col">Employee Name</th>
                                            <th scope="col">Volunteer Hours</th>
                                            <th scope="col">Travel Hours</th>
                                            <th scope="col">Lives Impacted</th>

                                            <th scope="col">Business Unit</th>
                                            <th scope="col">Event Status</th>
                                            <th scope="col">IIEP Category</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            eventsList.length ?
                                                eventsList.map(
                                                    eachObj => (
                                                        <tr key={eachObj.id}>
                                                            <td>{eachObj.event_id}</td>
                                                            <td>{eachObj.base_location}</td>
                                                            <td>{eachObj.beneficiary_name}</td>
                                                            <td>{eachObj.council_name}</td>
                                                            <td>{eachObj.event_name}</td>
                                                            <td>{eachObj.event_description}</td>
                                                            <td>{eachObj.event_date}</td>
                                                            <td>{eachObj.employee_id}</td>
                                                            <td>{eachObj.employee_name}</td>
                                                            <td>{eachObj.volunteer_hours}</td>
                                                            <td>{eachObj.travel_hours}</td>
                                                            <td>{eachObj.lives_impacted}</td>
                                                            <td>{eachObj.business_unit}</td>
                                                            <td>{eachObj.event_status}</td>
                                                            <td>{eachObj.iiep_category}</td>
                                                        </tr>)
                                                )
                                                : null
                                        }

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </React.Fragment>
            
            } 
                
            </>
        );
    }
}
export default Reports;