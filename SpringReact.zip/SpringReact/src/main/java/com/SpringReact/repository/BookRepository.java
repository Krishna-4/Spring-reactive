package com.SpringReact.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.SpringReact.model.Book;

public interface BookRepository extends ReactiveCrudRepository<Book, Long> {}
