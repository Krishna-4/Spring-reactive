package com.SpringReact.controllers;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.SpringReact.model.Event;
import com.SpringReact.repository.EventRepository;

import reactor.core.publisher.Flux;

@RestController
public class EventsController {
	
	Session mailSession;
	private static String[] columns = {"event_id","base_location","beneficiary_name","council_name","event_name","event_description","event_date","employee_id","employee_name","volunteer_hours","travel_hours","lives_impacted","business_unit","event_status","iiep_category"};
	
	@Autowired
	private EventRepository repository;
	List<Event> output = new ArrayList<Event>();
	
	@GetMapping("/getEvents")
	public Flux<Event> getEvents(){
		return repository.findAll();
	} 	
	
	private void copyToExcel(List<Event> output) {
		
		Workbook workbook = new XSSFWorkbook();
		CreationHelper createHelper = workbook.getCreationHelper();
		Sheet sheet = workbook.createSheet("Events");
		
		Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.RED.getIndex());
        
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
        Row headerRow = sheet.createRow(0);
        
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy"));
        
        int rowNum = 1;
        for(Event eve: output) {
            Row row = sheet.createRow(rowNum++);
            

            row.createCell(0)
                    .setCellValue(eve.getEvent_id());

            row.createCell(1)
                    .setCellValue(eve.getBase_location());
            
            row.createCell(2)
        		.setCellValue(eve.getBeneficiary_name());
            
            row.createCell(3)
            	.setCellValue(eve.getCouncil_name());
            
            row.createCell(4)
        		.setCellValue(eve.getEvent_name());
            
            row.createCell(5)
        		.setCellValue(eve.getEvent_description());

            Cell dateOfBirthCell = row.createCell(6);
            dateOfBirthCell.setCellValue(eve.getEvent_date());
            dateOfBirthCell.setCellStyle(dateCellStyle);
            
            row.createCell(7)
        		.setCellValue(eve.getEmployee_id());

            row.createCell(8)
                  .setCellValue(eve.getEmployee_name());
            
            row.createCell(9)
        		.setCellValue(eve.getVolunteer_hours());
            
            row.createCell(10)
    		.setCellValue(eve.getTravel_hours());
            
            row.createCell(11)
    		.setCellValue(eve.getLives_impacted());
            
            row.createCell(12)
    		.setCellValue(eve.getBusiness_unit());
            
            row.createCell(13)
    		.setCellValue(eve.getEvent_status());
            
            row.createCell(14)
    		.setCellValue(eve.getIiep_category());
        }
        
        for(int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
        FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream("JsonExcel.xlsx");
			workbook.write(fileOut);
	        fileOut.close();
	        workbook.close(); // Closing the workbook
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@GetMapping("/getEvents/{eventId}")
	public Flux<Event> getEventsById(@PathVariable String eventId){
		return repository.findAllByEvent_id(eventId);
	} 
	
	@GetMapping("/getEventsByVh/{vh}")
	public Flux<Event> getEventsByVolunteerHours(@PathVariable int vh){
		return repository.findAllByVolunteer_hours(vh);
	} 
	
	@PostMapping("/sendEmail")
	public void sendEmail(){
		generateExcel();
		
		final String username = "krishnasvnc@gmail.com";
        final String password = "1234qwE$";

        Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("krishnasvnc@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse("chaitanya750@gmail.com")
            );
            message.setSubject("Testing Gmail TLS");
            message.setText("Dear Mail Crawler,"
                    + "\n\n Please do not spam my email!");

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
	}

	private void generateExcel() {
		Flux<Event> values = repository.findAll();
		values.subscribe((next)->{
			output.add(next);
		});
		copyToExcel(output);		
	} 
}
